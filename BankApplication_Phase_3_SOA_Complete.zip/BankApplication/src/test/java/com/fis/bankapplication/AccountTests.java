package com.fis.bankapplication;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;

import java.util.Date;
import java.util.List;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.model.Customer;
import com.fis.bankapplication.model.Transaction;
import com.fis.bankapplication.service.AccountService;
import com.fis.bankapplication.service.CustomerService;
import com.fis.bankapplication.service.TransactionService;

@SpringBootTest
class AccountTests {

    @Autowired
    AccountService accountService;
    
	@Autowired
	CustomerService customerService;
	
    @Autowired
    TransactionService transactionService;
    
    // Test adding an account
    @Test
	public void testAddAccount() {
    	
    	// Create a customer
    	Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
		customerService.addCustomer(customer);
		
		// Create an account associated with the customer
		Account account = new Account(1, customer, "Savings", "Aundh", new Date(), "bipul123", 1000.0);
		
		// Add the account
		String result = accountService.addAccount(account);

		// Asserting the account addition
		assertEquals("Account added Successfully", result);
	}

    // Test updating an account
	@Test
	public void testUpdateAccount() {
		Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
		customerService.addCustomer(customer);
		
		Account account = new Account(1, customer, "Savings", "Aundh", new Date(), "bipul123", 1000.0);
		account.setBranch("Baner");
		String result = accountService.updateAccount(account);

		assertEquals("Account updated Successfully", result);
	}

	// Test deleting an account
//	@Test
//	public void testDeleteAccount() {
//		Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
//		customerService.addCustomer(customer);
//		
//		Account account = new Account(1, customer, "Savings", "Aundh", new Date(), "bipul123", 1000.0);
//		accountService.addAccount(account);
//
//		// delete the transactions first, for maintaining the referential integrity, first delete child records then the parent records
//		
//
//		List<Transaction> transactions = transactionService.getTransactionsForAccount(1);
//		
//		for (Transaction transaction : transactions) {
//			transactionService.deleteTransaction(transaction.getId());
//		}
//		
//		String result = accountService.deleteAccount(1);
//
//		assertEquals("Account Deleted Successfully", result);
//	}

	// Test getting an account
	@Test
	public void testGetAccount() {		
		Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
		customerService.addCustomer(customer);

		Account expectedAccount = new Account(1, customer, "Savings", "Aundh", new Date(), "bipul123", 1000.0);
		
		accountService.addAccount(expectedAccount);
		
		Account actualAccount = accountService.getAccount(1);
	
		assertNotNull(actualAccount);
		assertEquals(expectedAccount.getId(), actualAccount.getId());

	}
	
	// Test depositing
    @Test
    public void testDeposit() {
		Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
		customerService.addCustomer(customer);
		
        Account account = new Account(1, customer, "Savings", "Aundh", new Date(), "bipul123", 1000.0);
        accountService.addAccount(account);        
        
        String result = accountService.deposit(account.getId(), 500);
        
        assertEquals("Deposit of 500.0 successful. New balance: 1500.0", result);
    }

    // Test withdrawing
    @Test
    public void testWithdraw() {    	
    	Customer customer = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
		customerService.addCustomer(customer);
		
        Account account = new Account(1, customer, "Savings", "Aundh", new Date(), "bipul123", 1000.0);
        accountService.addAccount(account);
        
        String result = accountService.withdraw(account.getId(), 500);
        
        assertEquals("Withdraw of 500.0 successful. New balance: 500.0", result);
    }

    // Test fund transfer
    @Test
    public void testFundTransfer() {    	
    	Customer customerTo = new Customer(1, "Bipul", "9876543210", "x@gmail.com", "333344445555", new Date(), "Pune", "Patna", "SE1");
		customerService.addCustomer(customerTo);
		
		Customer customerFrom = new Customer(2, "Gautam", "9876543210", "y@gmail.com", "443344445555", new Date(), "Pune", "Patna", "SE2");
		customerService.addCustomer(customerFrom);
		
        Account toAccount = new Account(1, customerTo, "Savings", "Aundh", new Date(), "bipul123", 1000.0);
        accountService.addAccount(toAccount);
        
        Account fromAccount = new Account(2, customerFrom, "Savings", "Baner", new Date(), "bipul123", 2000.0);
        accountService.addAccount(fromAccount);
        
        String result = accountService.fundTransfer(fromAccount.getId(), toAccount.getId(), 500.0, "Transfer");

        assertEquals("Fund transfer of 500.0 successful. New balance for sender: 1500.0, new balance for receiver: 1500.0", result);
    }

}