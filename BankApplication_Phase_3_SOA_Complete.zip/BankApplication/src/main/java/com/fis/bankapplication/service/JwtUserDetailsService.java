package com.fis.bankapplication.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.fis.bankapplication.model.DAOUser;
import com.fis.bankapplication.model.UserDTO;
import com.fis.bankapplication.repository.UserDao;

@Service
public class JwtUserDetailsService implements UserDetailsService {
	
	@Autowired
	private UserDao userDao;

	@Autowired
	private PasswordEncoder bcryptEncoder;

	// Method from UserDetailsService interface to load user by username
	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		
		// Fetch user details from the repository based on the provided username
		DAOUser user = userDao.findByUsername(username);
		
		// Throw an exception if the user is not found
		if (user == null) {
			throw new UsernameNotFoundException("User not found with username: " + username);
		}
		
		// Return user details in Spring Security's UserDetails format
		return new org.springframework.security.core.userdetails.User(user.getUsername(), user.getPassword(),
				new ArrayList<>());
	}
	
	// Method to save a new user
	public DAOUser save(UserDTO user) {
		
		// Create a new DAOUser object
		DAOUser newUser = new DAOUser();
		
		// Set the username, encode the password, and set the user role
		newUser.setUsername(user.getUsername());
		newUser.setPassword(bcryptEncoder.encode(user.getPassword()));
		newUser.setRole(user.getRole());
		
		// Save the new user in the repository and return the saved user
		return userDao.save(newUser);
	}
}