package com.fis.bankapplication.service;

import com.fis.bankapplication.model.Account;
import com.fis.bankapplication.exceptions.AccountNotFoundException;

import java.util.List;

public interface AccountService {
	
	// Method to add an account
    public String addAccount(Account account);
    
    // Method to update an account
    public String updateAccount(Account account);
    
    // Method to delete an account by its ID
    public String deleteAccount(long accountId);
    
    // Method to get an account by its ID
    public Account getAccount(long accountId) throws AccountNotFoundException;
    
    // Method to get all accounts
    public List<Account> getAllAccounts();
    
    // Method to deposit an amount to an account
    public String deposit(long accountId, double amount);
    
    // Method to withdraw an amount from an account
    public String withdraw(long accountId, double amount);
    
    // Method to perform fund transfer between accounts
	public String fundTransfer(long fromAccountNumber, long toAccountNumber, double amount, String transactionType);
	
	// Method to retrieve accounts based on customer IDs
    public List<Account> getAccountsByCustomerId(long customerId);
	
    // Method to calculate the total balance for a given customer ID
    public double getTotalBalanceByCustomerId(long customerId);
    
}